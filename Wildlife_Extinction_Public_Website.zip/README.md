# Wildlife Extinction Risk Predictor

**Class XII-A AI/ML capstone · Public Streamlit website**

This repository contains an interactive educational application that demonstrates a machine-learning classification workflow for wildlife extinction-risk categories.

> **Scientific integrity notice:** The included training dataset and target labels are synthetic, generated only to demonstrate the code. The model is not trained on real wildlife observations, its metrics are not real-world performance, and its output is not an IUCN assessment or a real probability of extinction. Do not use it for actual conservation decisions.

## Features

- Interactive species risk-assessment form.
- Eight population, habitat and threat indicators.
- Random Forest classification into Low, Moderate, High or Critical demonstration classes.
- Model class-score chart, downloadable assessment CSV and dataset export.
- Model-insights tab with synthetic-data metrics, confusion matrix and global feature importance.
- Methodology and limitations explained inside the app.
- No API keys or paid services required.

## Public deployment (recommended: Streamlit Community Cloud)

### 1. Create a GitHub repository

1. Sign in to GitHub or create an account.
2. Choose **New repository**.
3. Name it `wildlife-extinction-risk-predictor`.
4. Set visibility to **Public** if you want anyone to see the source code.
5. Create the repository.
6. Upload the files from this project folder to the repository's root: `app.py`, `demo_wildlife_dataset.csv`, `requirements.txt`, `README.md`, and `.gitignore`.

Keep `app.py`, `requirements.txt` and `demo_wildlife_dataset.csv` together at the repository root. Do not upload the `.venv` folder or Python cache files.

### 2. Deploy the website

1. Open **https://share.streamlit.io/**.
2. Sign in using GitHub and authorize Streamlit Community Cloud.
3. Choose **Create app**.
4. Select the repository `wildlife-extinction-risk-predictor`.
5. Select branch `main` (or the branch you used).
6. Set the main file path to `app.py`.
7. Optionally choose an available app subdomain, then select **Deploy**.
8. When deployment succeeds, Streamlit gives you a public `https://....streamlit.app` URL. Share that URL.

Streamlit's official deployment guide: https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy

### 3. Updating the public website

When you commit updated files to the connected GitHub repository, Streamlit Community Cloud detects the change and redeploys the app. Check the app's logs in Streamlit if a deployment fails.

## Run locally on Windows

Install Python 3.10 or later, extract this project folder, then open Command Prompt inside the folder and run:

```bat
py -m venv .venv
.venv\Scripts\activate
py -m pip install -r requirements.txt
py -m streamlit run app.py
```

Open the local address printed in the terminal (normally `http://localhost:8501`).

## Project files

| File | Purpose |
|---|---|
| `app.py` | Streamlit interface, data checks, Random Forest training, prediction and charts |
| `demo_wildlife_dataset.csv` | 5,000 generated training examples; synthetic demonstration data only |
| `requirements.txt` | Python package dependencies for deployment |
| `README.md` | Setup, deployment and scientific limitations |
| `.gitignore` | Excludes local environment and cache files |

## Model design

- **Algorithm:** Random Forest classifier.
- **Inputs:** population decline, habitat loss, climate-related pressure, human interference, hunting/overexploitation, pollution, disease/invasive species pressure and protected habitat coverage.
- **Target:** four synthetic classes — Low, Moderate, High and Critical.
- **Demo evaluation:** stratified random 80/20 train/test split; balanced accuracy, weighted F1 and confusion matrix.

The labels are generated from an illustrative weighted score and divided into four relative bands in this synthetic dataset. The boundaries are not ecological thresholds. This makes the app runnable without a real-world dataset, but it does **not** establish that the model has learned real extinction biology.

## How to make the project scientifically meaningful

1. Obtain a legitimate, documented dataset with clear species/population identifiers, dates, geographic coverage and expert-grounded target labels.
2. Define exactly what is being predicted (for example, a documented conservation category at a stated future time horizon).
3. Check label quality, missingness, sample bias, class imbalance and leakage.
4. Split by time and geography, not only random rows, to test generalization.
5. Calibrate uncertainty and seek conservation-expert review before any real-world use.
6. Only then report validation metrics as evidence about the intended task.

## Privacy and safety

The app does not require accounts, does not ask for exact wildlife coordinates and does not contain API keys. Avoid publishing precise locations of vulnerable species or sensitive field observations.
