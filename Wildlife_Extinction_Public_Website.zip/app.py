from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import balanced_accuracy_score, confusion_matrix, f1_score
from sklearn.model_selection import train_test_split

# -----------------------------------------------------------------------------
# App configuration and constants
# -----------------------------------------------------------------------------
st.set_page_config(
    page_title="Wildlife Extinction Risk Predictor",
    page_icon="🌿",
    layout="wide",
    initial_sidebar_state="expanded",
)

APP_DIR = Path(__file__).resolve().parent
DATA_FILE = APP_DIR / "demo_wildlife_dataset.csv"
RISK_ORDER = ["Low", "Moderate", "High", "Critical"]
RISK_ICONS = {"Low": "🟢", "Moderate": "🟡", "High": "🟠", "Critical": "🔴"}
RISK_DESCRIPTIONS = {
    "Low": "The model places this input in its lowest demonstration risk class.",
    "Moderate": "The model places this input in its moderate demonstration risk class.",
    "High": "The model places this input in its high demonstration risk class.",
    "Critical": "The model places this input in its highest demonstration risk class.",
}
FEATURES = [
    "population_decline_pct",
    "habitat_loss_pct",
    "climate_anomaly_score",
    "human_interference_score",
    "hunting_pressure_score",
    "pollution_score",
    "disease_invasive_score",
    "protection_coverage_pct",
]
LABEL = "risk_category"
FEATURE_LABELS = {
    "population_decline_pct": "Population decline",
    "habitat_loss_pct": "Habitat loss",
    "climate_anomaly_score": "Climate-related pressure",
    "human_interference_score": "Human interference",
    "hunting_pressure_score": "Hunting / overexploitation",
    "pollution_score": "Pollution pressure",
    "disease_invasive_score": "Disease / invasive species",
    "protection_coverage_pct": "Protected habitat coverage",
}

# -----------------------------------------------------------------------------
# Styling
# -----------------------------------------------------------------------------
st.markdown(
    """
    <style>
      @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap');
      html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
      .stApp { background: #f5f7f3; }
      [data-testid="stHeader"] { background: rgba(245,247,243,0.88); }
      .block-container { padding-top: 1.5rem; padding-bottom: 3rem; max-width: 1280px; }
      h1, h2, h3 { font-family: 'Manrope', sans-serif; color: #173b2b; }
      .hero {
        background: linear-gradient(118deg, #102f24 0%, #1d5940 58%, #337a53 100%);
        padding: 2rem 2.1rem; border-radius: 22px; color: #f5fff8;
        margin-bottom: 1.15rem; box-shadow: 0 12px 28px rgba(24,66,45,.13);
      }
      .hero-kicker { color: #c1e5cb; text-transform: uppercase; letter-spacing: .15em;
        font-size: .73rem; font-weight: 700; margin-bottom: .55rem; }
      .hero-title { color: white; font: 800 clamp(1.8rem, 4vw, 2.8rem)/1.1 'Manrope',sans-serif;
        letter-spacing: -.04em; margin: 0 0 .7rem 0; }
      .hero-copy { color: #e0f0e5; font-size: 1rem; max-width: 760px; line-height: 1.6; margin: 0; }
      .section-eyebrow { color: #548064; text-transform: uppercase; letter-spacing: .12em;
        font-weight: 700; font-size: .72rem; margin-bottom: .25rem; }
      .notice {
        border-left: 4px solid #d69a31; background: #fff8e9; color: #624718;
        padding: .9rem 1rem; border-radius: 9px; margin: .85rem 0 1.2rem 0;
        font-size: .91rem; line-height: 1.55;
      }
      .soft-card { background: white; border: 1px solid #e3eae2; padding: 1rem 1.1rem;
        border-radius: 15px; height: 100%; }
      .small-muted { color: #63756a; font-size: .86rem; }
      div[data-testid="stMetric"] { background: white; border: 1px solid #e3eae2;
        padding: .85rem 1rem; border-radius: 14px; }
      div.stButton > button[kind="primary"], div.stFormSubmitButton > button {
        background: #1e6846; border: 1px solid #1e6846; border-radius: 10px;
        font-weight: 700; min-height: 2.8rem; }
      div.stButton > button[kind="primary"]:hover, div.stFormSubmitButton > button:hover {
        background: #174f36; border-color: #174f36; }
      [data-testid="stSidebar"] { background: #edf3ed; }
      .footer { color: #718076; font-size: .8rem; text-align: center;
        border-top: 1px solid #e0e8df; padding-top: 1rem; margin-top: 2rem; }
    </style>
    """,
    unsafe_allow_html=True,
)

# -----------------------------------------------------------------------------
# Data loading and model training. Fail with a readable message if files break.
# -----------------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def load_dataset(path_string: str) -> pd.DataFrame:
    path = Path(path_string)
    if not path.is_file():
        raise FileNotFoundError(f"The dataset file was not found: {path.name}")
    frame = pd.read_csv(path)
    required = FEATURES + [LABEL]
    missing = [column for column in required if column not in frame.columns]
    if missing:
        raise ValueError("Dataset is missing required columns: " + ", ".join(missing))
    frame = frame[required].copy()
    for column in FEATURES:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    frame[LABEL] = frame[LABEL].astype("string").str.strip()
    frame = frame.dropna(subset=required)
    frame = frame[frame[LABEL].isin(RISK_ORDER)]
    if len(frame) < 40:
        raise ValueError("The dataset needs at least 40 complete labelled rows to train this demo model.")
    if frame[LABEL].nunique() < 2:
        raise ValueError("The dataset must contain at least two different risk categories.")
    if not np.isfinite(frame[FEATURES].to_numpy(dtype=float)).all():
        raise ValueError("The dataset contains invalid numeric values.")
    return frame.reset_index(drop=True)


@st.cache_resource(show_spinner="Training the demonstration model…")
def train_model(path_string: str) -> tuple[Any, dict[str, Any], pd.DataFrame, pd.DataFrame]:
    frame = load_dataset(path_string)
    x = frame[FEATURES]
    y = frame[LABEL]
    x_train, x_test, y_train, y_test = train_test_split(
        x, y, test_size=0.20, random_state=42, stratify=y
    )
    model = RandomForestClassifier(
        n_estimators=300,
        max_depth=12,
        min_samples_leaf=2,
        class_weight="balanced_subsample",
        random_state=42,
        n_jobs=-1,
    )
    model.fit(x_train, y_train)
    predictions = model.predict(x_test)
    metrics = {
        "rows": int(len(frame)),
        "train_rows": int(len(x_train)),
        "test_rows": int(len(x_test)),
        "balanced_accuracy": float(balanced_accuracy_score(y_test, predictions)),
        "weighted_f1": float(f1_score(y_test, predictions, average="weighted", zero_division=0)),
        "confusion_matrix": confusion_matrix(y_test, predictions, labels=RISK_ORDER),
        "test_labels": y_test,
        "test_predictions": predictions,
    }
    importance = pd.DataFrame({
        "Feature": [FEATURE_LABELS[name] for name in FEATURES],
        "Importance": model.feature_importances_,
    }).sort_values("Importance", ascending=False)
    return model, metrics, importance, frame


try:
    model, metrics, feature_importance, dataset = train_model(str(DATA_FILE))
except Exception as exc:  # A friendly on-screen error is more useful than a raw traceback.
    st.error("The app could not load or train its model.")
    st.code(str(exc))
    st.info("Check that app.py and demo_wildlife_dataset.csv are in the same GitHub repository folder.")
    st.stop()

# -----------------------------------------------------------------------------
# Header and sidebar
# -----------------------------------------------------------------------------
st.markdown(
    """
    <section class="hero">
      <div class="hero-kicker">AI for biodiversity · Class XII-A capstone</div>
      <div class="hero-title">Wildlife Extinction<br>Risk Predictor</div>
      <p class="hero-copy">Explore how population trends, habitat pressure and environmental threats
      can be combined in a machine-learning classification workflow to support conservation awareness.</p>
    </section>
    """,
    unsafe_allow_html=True,
)
st.markdown(
    '<div class="notice"><strong>Educational prototype — not a real-world extinction forecast.</strong> '
    'The included training dataset and its labels are synthetic (computer-generated). Predictions and '
    'test metrics demonstrate the software workflow only; they are not IUCN assessments, verified '
    'species risk estimates, or evidence of real-world model accuracy.</div>',
    unsafe_allow_html=True,
)

with st.sidebar:
    st.markdown("## 🌿 Project panel")
    st.caption("Wildlife Extinction Prediction · Session 2026–27")
    st.markdown("---")
    st.markdown("**Model status**")
    st.success("Demonstration model trained")
    st.metric("Synthetic training records", f"{metrics['rows']:,}")
    st.metric("Input indicators", len(FEATURES))
    st.markdown("---")
    st.markdown("**Risk categories**")
    for category in RISK_ORDER:
        st.write(f"{RISK_ICONS[category]}  {category}")
    st.markdown("---")
    st.caption("For a research-grade system, replace the synthetic file with verified, population-level conservation data and validate it with experts.")

# -----------------------------------------------------------------------------
# Main navigation
# -----------------------------------------------------------------------------
predict_tab, insights_tab, method_tab = st.tabs([
    "🔎  Risk assessment",
    "📊  Model insights",
    "🧭  Method & limitations",
])

with predict_tab:
    st.markdown('<div class="section-eyebrow">Species assessment</div>', unsafe_allow_html=True)
    st.header("Enter the available species information")
    st.write("Use documented observations where possible. The impact sliders are demonstration indices, not official scientific scales.")

    with st.form("prediction_form", clear_on_submit=False):
        species_name = st.text_input("Species name", value="Bengal tiger", max_chars=100,
                                     help="This is a display label only; the species name itself is not used by the model.")
        st.markdown("##### Population and habitat")
        col1, col2 = st.columns(2)
        with col1:
            population_decline = st.slider("Population decline over the selected period (%)", 0, 100, 35)
            habitat_loss = st.slider("Habitat loss (%)", 0, 100, 40)
            protection = st.slider("Protected habitat coverage (%)", 0, 100, 50)
        with col2:
            climate = st.slider("Climate-related pressure (0–100)", 0, 100, 30)
            human = st.slider("Human interference (0–100)", 0, 100, 45)
            records = st.number_input("Number of supporting records available", min_value=0, max_value=100000, value=80, step=1,
                                      help="Used only as a data-coverage warning. It is not a model input.")
        st.markdown("##### Other threats")
        col3, col4, col5 = st.columns(3)
        with col3:
            hunting = st.slider("Hunting / overexploitation (0–100)", 0, 100, 35)
        with col4:
            pollution = st.slider("Pollution pressure (0–100)", 0, 100, 25)
        with col5:
            disease = st.slider("Disease / invasive species (0–100)", 0, 100, 20)
        submitted = st.form_submit_button("Analyse species risk", type="primary", use_container_width=True)

    if submitted:
        if not species_name.strip():
            st.error("Please enter a species name before running the assessment.")
        else:
            row = pd.DataFrame([{
                "population_decline_pct": population_decline,
                "habitat_loss_pct": habitat_loss,
                "climate_anomaly_score": climate,
                "human_interference_score": human,
                "hunting_pressure_score": hunting,
                "pollution_score": pollution,
                "disease_invasive_score": disease,
                "protection_coverage_pct": protection,
            }], columns=FEATURES)
            predicted_class = str(model.predict(row)[0])
            class_scores = model.predict_proba(row)[0]
            model_classes = list(model.classes_)
            score_frame = pd.DataFrame({
                "Risk category": model_classes,
                "Model class score": class_scores,
            })
            score_frame["Risk category"] = pd.Categorical(score_frame["Risk category"], categories=RISK_ORDER, ordered=True)
            score_frame = score_frame.sort_values("Risk category")

            st.markdown("---")
            st.markdown('<div class="section-eyebrow">Assessment output</div>', unsafe_allow_html=True)
            left, right = st.columns([1.05, 1.4], gap="large")
            with left:
                st.markdown(f"### {species_name.strip()}")
                st.markdown(f"## {RISK_ICONS[predicted_class]} {predicted_class} risk class")
                st.write(RISK_DESCRIPTIONS[predicted_class])
                st.caption("This category is the model's output from synthetic training labels, not the species' official conservation status.")
                if records < 30:
                    st.warning("Fewer than 30 supporting records entered. The information base is very limited; interpret this demonstration output with extra caution.")
                else:
                    st.info(f"You entered {records:,} supporting records. Record count is shown as context and does not change the model prediction.")
            with right:
                fig = px.bar(
                    score_frame,
                    x="Risk category",
                    y="Model class score",
                    color="Risk category",
                    category_orders={"Risk category": RISK_ORDER},
                    color_discrete_map={"Low": "#64a77b", "Moderate": "#e2bd54", "High": "#e58b45", "Critical": "#c65c55"},
                    range_y=[0, 1],
                    text=score_frame["Model class score"].map(lambda value: f"{value:.0%}"),
                )
                fig.update_layout(
                    title="Model scores by category (not extinction probabilities)",
                    showlegend=False, yaxis_title="Model class score", xaxis_title="",
                    margin=dict(l=10, r=10, t=55, b=10), height=330,
                    paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                )
                fig.update_yaxes(tickformat=".0%", gridcolor="#e7eee7")
                st.plotly_chart(fig, use_container_width=True)

            st.markdown("#### Indicators submitted")
            input_table = pd.DataFrame([
                (FEATURE_LABELS[key], float(row.iloc[0][key])) for key in FEATURES
            ], columns=["Indicator", "Entered value (0–100)"])
            st.dataframe(input_table, hide_index=True, use_container_width=True)

            report = {
                "species_name": species_name.strip(),
                "predicted_demo_risk_category": predicted_class,
                "supporting_records_context_only": int(records),
                **{key: float(row.iloc[0][key]) for key in FEATURES},
                **{f"model_score_{key}": float(value) for key, value in zip(model_classes, class_scores)},
                "data_note": "Synthetic demonstration model; not an official conservation assessment.",
            }
            st.download_button(
                "⬇ Download assessment CSV",
                data=pd.DataFrame([report]).to_csv(index=False).encode("utf-8"),
                file_name="wildlife_demo_assessment.csv",
                mime="text/csv",
                use_container_width=False,
            )

with insights_tab:
    st.markdown('<div class="section-eyebrow">What the model learned</div>', unsafe_allow_html=True)
    st.header("Demonstration model insights")
    st.markdown(
        '<div class="notice"><strong>Read these metrics carefully.</strong> They measure how well the model '
        'reproduces patterns in generated demonstration labels. They do not measure its ability to predict '
        'real species extinction risk.</div>', unsafe_allow_html=True
    )
    m1, m2, m3 = st.columns(3)
    m1.metric("Balanced accuracy", f"{metrics['balanced_accuracy']:.1%}")
    m2.metric("Weighted F1 score", f"{metrics['weighted_f1']:.3f}")
    m3.metric("Held-out test records", f"{metrics['test_rows']:,}")
    st.caption(f"Split: {metrics['train_rows']:,} training records and {metrics['test_rows']:,} test records (stratified 80/20 split).")

    c1, c2 = st.columns(2, gap="large")
    with c1:
        st.subheader("Global feature importance")
        importance_fig = px.bar(
            feature_importance.sort_values("Importance"),
            x="Importance", y="Feature", orientation="h",
            color_discrete_sequence=["#2e7651"],
        )
        importance_fig.update_layout(
            xaxis_title="Relative model importance", yaxis_title="",
            margin=dict(l=5, r=10, t=15, b=10), height=390,
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        )
        st.plotly_chart(importance_fig, use_container_width=True)
        st.caption("These are global model feature-importance values, not causal effects or explanations for one species.")
    with c2:
        st.subheader("Held-out test confusion matrix")
        cm = metrics["confusion_matrix"]
        cm_fig = go.Figure(data=go.Heatmap(
            z=cm,
            x=RISK_ORDER,
            y=RISK_ORDER,
            colorscale=[[0, "#f0f5ef"], [1, "#266747"]],
            text=cm,
            texttemplate="%{text}",
            showscale=False,
        ))
        cm_fig.update_layout(
            xaxis_title="Predicted category", yaxis_title="Actual synthetic category",
            margin=dict(l=5, r=5, t=15, b=10), height=390,
            paper_bgcolor="rgba(0,0,0,0)",
        )
        st.plotly_chart(cm_fig, use_container_width=True)
        st.caption("Rows are actual generated labels; columns are model predictions.")

    st.download_button(
        "⬇ Download demonstration dataset",
        data=dataset.to_csv(index=False).encode("utf-8"),
        file_name="demo_wildlife_dataset.csv",
        mime="text/csv",
    )

with method_tab:
    st.markdown('<div class="section-eyebrow">Project methodology</div>', unsafe_allow_html=True)
    st.header("How the application works")
    stages = [
        ("01", "Input", "The user enters population decline, habitat loss, climate pressure, human interference, hunting pressure, pollution, disease/invasive pressure and protection coverage."),
        ("02", "Preprocessing", "The app checks that the training file has the expected columns, numeric values and valid risk labels."),
        ("03", "Training", "A Random Forest classifier learns from labelled synthetic demonstration records."),
        ("04", "Testing", "A stratified 80/20 split is used to calculate demonstration balanced accuracy, weighted F1 and a confusion matrix."),
        ("05", "Prediction", "New input values are passed to the trained model, which returns one of four demonstration risk categories."),
    ]
    for number, title, description in stages:
        with st.container(border=True):
            a, b = st.columns([0.12, 0.88])
            with a:
                st.markdown(f"### {number}")
            with b:
                st.markdown(f"**{title}**")
                st.write(description)

    st.subheader("Important limitations and responsible use")
    st.markdown("""
    - **Synthetic training data:** The supplied dataset was generated for software demonstration. It is not a collection of actual species observations.
    - **Illustrative labels:** The categories were assigned using a made-up weighted scoring rule, not IUCN criteria or expert review.
    - **Not a real extinction probability:** Class scores indicate how the model distributes its output across the four synthetic classes. They are not calibrated probabilities of extinction.
    - **Not an IUCN assessment:** The application does not determine or replace a species' official IUCN Red List category.
    - **Data quality matters:** A real system needs reliable, time-stamped, species- or population-level records, a clear target label and careful treatment of missing values and sampling bias.
    - **Proper validation:** A research-grade model should be evaluated on later years and on geographic regions excluded from training, then reviewed by conservation specialists.
    - **Safe location handling:** This prototype does not ask users to submit precise locations of vulnerable wildlife.
    """)
    st.subheader("Suggested real-data upgrade")
    st.write("Replace the demonstration CSV with verified conservation data. Define the prediction target first, document each variable and unit, then conduct temporal and geographic holdout validation. Do not advertise performance metrics until that evaluation has been completed.")

st.markdown(
    '<div class="footer">Wildlife Extinction Prediction · Class XII-A · Educational capstone prototype<br>'
    'Built with Python, Streamlit, pandas, scikit-learn and Plotly.</div>',
    unsafe_allow_html=True,
)
