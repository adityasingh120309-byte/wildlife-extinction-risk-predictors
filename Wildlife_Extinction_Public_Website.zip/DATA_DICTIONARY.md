# Demonstration dataset dictionary

All rows and labels in `demo_wildlife_dataset.csv` are generated synthetic examples. Values are not observed wildlife measurements.

| Column | Meaning in this demo | Unit / range |
|---|---|---|
| `population_decline_pct` | Illustrative population decline indicator | 0–100% |
| `habitat_loss_pct` | Illustrative habitat loss indicator | 0–100% |
| `climate_anomaly_score` | Illustrative climate-related pressure index | 0–100 |
| `human_interference_score` | Illustrative human-interference index | 0–100 |
| `hunting_pressure_score` | Illustrative hunting / overexploitation index | 0–100 |
| `pollution_score` | Illustrative pollution pressure index | 0–100 |
| `disease_invasive_score` | Illustrative disease / invasive-species index | 0–100 |
| `protection_coverage_pct` | Illustrative protected habitat coverage | 0–100% |
| `risk_category` | Artificially assigned relative demo class (synthetic score bands) | Low / Moderate / High / Critical |

The numeric scales are placeholders for an educational UI. A real project must define scientifically valid units, data sources, observation windows and a defensible target label before model training.
